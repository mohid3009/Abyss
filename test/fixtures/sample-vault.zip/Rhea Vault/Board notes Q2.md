# Board notes Q2
- Approved annual pricing from [[Pricing v2]].
- Churn target under 3%. #metrics
- Hire first support person in Q3.
