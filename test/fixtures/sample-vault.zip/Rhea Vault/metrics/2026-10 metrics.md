#metrics
MRR: $18,400
Churn: 2.8%
New customers: 23
