#metrics
MRR: $19,900
Churn: 2.5%
New customers: 27
