#product
Signup → verify email → create workspace → invite team → first project → activated.
Drop-off is highest at invite team.
