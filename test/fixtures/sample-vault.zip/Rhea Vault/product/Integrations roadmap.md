#product
1. Slack (Q1)
2. Zapier (Q2)
3. HubSpot (later)
Requested by [[Arjun]].
