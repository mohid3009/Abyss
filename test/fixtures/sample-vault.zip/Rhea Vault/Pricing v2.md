---
tags: [pricing]
---
# Pricing v2
Decision: annual plan at 10x monthly (2 months free). Monthly stays $29.
Raised by [[Call — Arjun, March]] and confirmed in [[Board notes Q2]].
