#idea
Charge per extra seat over 10? Compare with [[Pricing v2]]. Also see [[Competitor pricing]].
