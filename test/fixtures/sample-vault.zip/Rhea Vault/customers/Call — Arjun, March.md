#customer #call
[[Arjun]] asked for an annual option and a Slack integration. Would pay upfront for a discount. Links: [[Pricing v2]].
