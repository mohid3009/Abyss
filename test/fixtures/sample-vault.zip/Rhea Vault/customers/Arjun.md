#customer
Arjun runs ops at Northwind. Renewal due January. See [[Call — Arjun, March]] and [[Integrations roadmap]].
